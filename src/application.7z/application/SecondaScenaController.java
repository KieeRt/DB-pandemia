package application;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.ParsePosition;
import java.time.LocalDate;
import java.util.Observable;

import com.sun.glass.events.MouseEvent;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.input.ContextMenuEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import oracle.net.aso.a;
import sun.nio.cs.AbstractCharsetProvider;


public class SecondaScenaController {
	 @FXML
	    private ToggleButton toggleButtonPersona;

	    @FXML
	    private ToggleGroup toggleGroupClasseGenerica;

	    @FXML
	    private ToggleButton toggleButtonLuogo;

	    @FXML
	    private ToggleButton toggleButtonControlloMedico;

	    @FXML
	    private ToggleButton toggleButtonIncontri;
	    
	    @FXML 
	    private ToggleButton toggleButtonVaccino;

	    @FXML
	    private TabPane schermataPersona;

	    @FXML
	    private DatePicker textDataNascitaPersona;

	    @FXML
	    private TextField textFieldCognomePersona;

	    @FXML
	    private TextField textFieldNomePersona;

	    @FXML
	    private TextField textComuneNascitaPersona;

	    @FXML
	    private TextField textFieldCFPersona;

	    @FXML
	    private TextField textFieldMail1Persona;

	    @FXML
	    private RadioButton tbMaschio;

	    @FXML
	    private ToggleGroup toggleGroupSessoPersonaGenerico;

	    @FXML
	    private RadioButton tbFemmina;

	    @FXML
	    private TextField textFieldMail2Persona;

	    @FXML
	    private TextField textFieldTelefono1Persona;

	    @FXML
	    private TextField textFieldTelefono2Persona;

	    @FXML
	    private TextField textFieldPersonaCognomeParentela1;

	    @FXML
	    private TextField textFieldPersonaNomeParentela1;

	    @FXML
	    private TextField textFieldPersonaCognomeParentela2;

	    @FXML
	    private TextField textFieldPersonaNomeParentela2;

	    @FXML
	    private ChoiceBox<String> sceltaParentela;

	    @FXML
	    private TextField textFieldPersonaCFParentela2;

	    @FXML
	    private TextField textFieldPersonaCFParentela1;

	    @FXML
	    private RadioButton radioBDatiPersonali;

	    @FXML
	    private ToggleGroup toggleGroupSelezioneCampiPersonaGenerica;

	    @FXML
	    private RadioButton radioBParentela;

	    @FXML
	    private RadioButton radioBStatoDellaSalute;

	    @FXML
	    private TextField textFieldPersonaCognomeStatoSalute;

	    @FXML
	    private TextField textFieldPersonaNomeStatoSalute;

	    @FXML
	    private TextField textFieldPersonaCFStatoSalute;

	    @FXML
	    private TextField textFieldPersonaMalattieCronicheStatoSalute;

	    @FXML
	    private DatePicker dataSintomiDatePickerStatoSalute;

	    @FXML
	    private DatePicker textDataTamponeEseguito;

	    @FXML
	    private RadioButton tbTamponeEseguitoSi;

	    @FXML
	    private ToggleGroup toggleGroupTamponeEseguito;

	    @FXML
	    private RadioButton tbTamponeEseguitoNo;

	    @FXML
	    private RadioButton tbQuarantenaSi;

	    @FXML
	    private ToggleGroup toggleGroupQuarantena;

	    @FXML
	    private RadioButton tbQuarantenaNo;

	    @FXML
	    private ChoiceBox<String> sceltaSintomi;

	    @FXML
	    private RadioButton tbFrequentaInPresenzaSi;

	    @FXML
	    private ToggleGroup toggleGroupFrequentaInPresenza;

	    @FXML
	    private RadioButton tbFrequentaInPresenzaNo;

	    @FXML
	    private TextField textCodiceFiscaleStudente;

	    @FXML
	    private TextField textNomeStudente;

	    @FXML
	    private TextField textCognomeStudente;

	    @FXML
	    private RadioButton radioBDatiPersonaliStudente;

	    @FXML
	    private RadioButton radioBCompagniStudente;

	    @FXML
	    private TextField textCodiceFiscaleCompagno1;

	    @FXML
	    private TextField textNomeCompagno1;

	    @FXML
	    private TextField textCognomeCompagno1;

	    @FXML
	    private TextField textCodiceFiscaleCompagno2;

	    @FXML
	    private TextField textNomeCompagno2;

	    @FXML
	    private TextField textCognomeCompagno2;

	    @FXML
	    private TextField textCodiceFiscaleLavoratore;

	    @FXML
	    private TextField textNomeLavoratore;

	    @FXML
	    private TextField textCognomeLavoratore;

	    @FXML
	    private RadioButton radioBDatiPersonaliLavoratore;

	    @FXML
	    private TextField textNomeSocieta;

	    @FXML
	    private ChoiceBox<String> tipoContrattoChoiceBox;

	    @FXML
	    private TextField textCodiceFiscaleCollega1;

	    @FXML
	    private TextField textNomeCollega1;

	    @FXML
	    private TextField textCognomeCollega1;

	    @FXML
	    private TextField textCodiceFiscaleCollega2;

	    @FXML
	    private TextField textNomeCollega2;

	    @FXML
	    private TextField textCognomeCollega2;

	    @FXML
	    private RadioButton radioBColleghiLavoratore;

	    @FXML
	    private CheckBox checkBoxLunediLavoratore;

	    @FXML
	    private CheckBox checkBoxVenerdiLavoratore;

	    @FXML
	    private CheckBox checkBoxGiovediLavoratore;

	    @FXML
	    private CheckBox checkBoxMercolediLavoratore;

	    @FXML
	    private CheckBox checkBoxMartediLavoratore;
	    
	    @FXML
	    private Label labelHelpCFPersona;
	    
	    @FXML
	    private CheckBox checkBoxSabatoLavoratore;

	    @FXML
	    private TabPane schermataLuogo;

	    @FXML
	    private TextField textCityDatiLuogo;

	    @FXML
	    private TextField textProvinciaDatiLuogo;

	    @FXML
	    private TextField textViaDatiLuogo;

	    @FXML
	    private TextField textNumeroCivicoDatiLuogo;

	    @FXML
	    private TextField textCAPDatiLuogo;

	    @FXML
	    private RadioButton radioBDatiLuogo;

	    @FXML
	    private TextField textIDLuogo;

	    @FXML
	    private TextField textNomeGestioneLuogo;

	    @FXML
	    private TextField textCognomeGestioneLuogo;

	    @FXML
	    private TextField textCodiceFiscaleGestioneLuogo;

	    @FXML
	    private TextField textViaGestioneLuogo;

	    @FXML
	    private TextField textNumCivicoGestioneLuogo;
	    
	    @FXML
	    private CheckBox checkBoxDomenicaLavoratore;
	    
	    @FXML
	    private RadioButton radioBGestioneLuogo;

	    @FXML
	    private TextField textIDLuogoGestioneLuogo;

	    @FXML
	    private TextField textViaAmbieneLavoro;

	    @FXML
	    private TextField textNumCivicoAmbienteLavoro;

	    @FXML
	    private TextField textIDLuogoAmbienteLavoro;

	    @FXML
	    private RadioButton radioBAmbienteLavoro;

	    @FXML
	    private TextField textIDAmbienteLavoro;

	    @FXML
	    private TextField textOrarioAAmbienteLavoro;

	    @FXML
	    private TextField textOrarioCAmbienteLavoro;

	    @FXML
	    private ComboBox<Integer> choicheBoxNumDipendentiAmbieneLavoro;

	    @FXML
	    private TextField textViaAmbienteStudio;

	    @FXML
	    private TextField textNumCivicoAmbienteStudio;

	    @FXML
	    private TextField textIDLuogoAmbienteStudio;

	    @FXML
	    private ChoiceBox<String> choicheBoxTipoAmbienteStudio;

	    @FXML
	    private RadioButton radioBAmbienteStudio;

	    @FXML
	    private TextField textIDAmbienteStudioAula;

	    @FXML
	    private RadioButton radioBAula;

	    @FXML
	    private TextField textID_Aula;

	    @FXML
	    private TextField textIDAmbienteStudio;

	    @FXML
	    private ComboBox<Integer> choicheBoxNumPostiAula;

	    @FXML
	    private TextField textViaAmbienteEventoOccasionale;

	    @FXML
	    private TextField textNumCivicoAmbienteEventoOccasionale;

	    @FXML
	    private TextField textIDLuogoAmbienteEventoOccasionale;

	    @FXML
	    private RadioButton radioBAmbienteEventoOccasionale;

	    @FXML
	    private TextField textDimensioniAmbienteEventoOccasionale;

	    @FXML
	    private RadioButton radioBLuogoApertoSi;

	    @FXML
	    private ToggleGroup toggleGroupLuogoApertoEventoOccasionale;

	    @FXML
	    private RadioButton radioBLuogoApertoNo;

	    @FXML
	    private TextField textIDAmbienteEventoOccasionale;

	    @FXML
	    private ComboBox<Integer> choicheBoxNumPartecipantiAmbienteEventoOccasionale;

	    @FXML
	    private TextField textViaAmbienteFamiliare;

	    @FXML
	    private TextField textNumCivicoAmbienteFamiliare;

	    @FXML
	    private TextField textIDLuogoAmbienteFamiliare;

	    @FXML
	    private RadioButton radioBAmbienteFamiliare;

	    @FXML
	    private TextField textDimensioneAmbienteFamiliare;

	    @FXML
	    private ChoiceBox<String> choicheBoxTipoAmbienteFamiliare;

	    @FXML
	    private TextField textIDAmbienteFamiliare;

	    @FXML
	    private TabPane schermataControlloMedico;

	    @FXML
	    private TextField textNomeMedicoControlloMedico;

	    @FXML
	    private TextField textNomeOspedaleControlloMedico;

	    @FXML
	    private RadioButton radioBDatiControlloMedico;

	    @FXML
	    private TextField textNomeControlloMedico;

	    @FXML
	    private TextField textCognomeControlloMedico;

	    @FXML
	    private TextField textCodiceFiscaleControlloMedico;

	    @FXML
	    private TextField textViaControlloMedico;

	    @FXML
	    private TextField textNumCivicoControlloMedico;

	    @FXML
	    private TextField textIDLuogoControlloMedico;

	    @FXML
	    private DatePicker datePickerDataControlloMedico;

	    @FXML
	    private ChoiceBox<String> choiceBoxTipoControlloMedico;

	    @FXML
	    private ChoiceBox<String> choiceBoxEsitoControlloMedico;

	    @FXML
	    private TextField textIDControlloMedico;

	    @FXML
	    private TabPane schermataGestioneIncontri;
	    
	    @FXML
	    private TabPane schermataVaccino;

	    @FXML
	    private TextField textNomeDatiIncontro;

	    @FXML
	    private TextField textCognomeDatiIncontro;

	    @FXML
	    private RadioButton radioBDatiIncontroVisita;

	    @FXML
	    private TextField textCodiceFiscaleDatiIncontro;

	    @FXML
	    private TextField textViaDatiIncontro;

	    @FXML
	    private TextField textNumCivicoDatiIncontro;

	    @FXML
	    private TextField textIDLuogoDatiIncontro;

	    @FXML
	    private TextField textorarioDatiIncontro;

	    @FXML
	    private DatePicker datePickerDataDatiIncontro;

	    @FXML
	    private MenuItem logoutButton;

	    @FXML
	    private MenuItem helpButton;

	    @FXML
	    private TextArea console2;
	    
	    @FXML
	    private Tooltip tooltip;
	    
	    @FXML
	    private TextArea textHelpCFPersona;
	    
	    // VARIABILI USATE PE Tooltip
	    
	    @FXML
	    private Label labelHelpIDStudente;
	    
	    @FXML
	    private TextArea textHelpIDStudente;
	    
	    @FXML
	    private Label labelHelpIDLavoratore;
	    
	    @FXML
	    private TextArea textHelpIDLavoratore;
	    
	    @FXML
	    private Label labelHelpIDLuogo;
	    
	    @FXML
	    private TextArea textHelpIDLuogo;
	    
	    @FXML
	    private Label labelHelpIDAmbienteLavoro;
	    
	    @FXML
	    private TextArea textHelpIDAmbienteLavoro;
	    
	    @FXML
	    private Label labelHelpIDAmbienteStudio;
	    
	    @FXML
	    private TextArea textHelpIDAmbienteStudio;
	    
	    @FXML
	    private Label labelHelpIDAula;
	    
	    @FXML
	    private TextArea textHelpIDAula;
	    
	    
	    @FXML
	    private Label labelHelpIDAmbienteEventoOcc;
	    
	    @FXML
	    private TextArea textHelpIDAmbienteEventoOcc;
	    
	    @FXML
	    private Label labelHelpIDAmbienteFamiliare;
	    
	    @FXML
	    private TextArea textHelpIDAmbienteFamiliare;
	    
	    @FXML
	    private Label labelHelpIDControlloMedico;
	    
	    @FXML
	    private TextArea textHelpIDControlloMedico;
	    
	    
	    
	    // CAMPI frequentazione istituzionale 
	    @FXML
	    private RadioButton radioBLuoghiIstituzionaliFrequentati;
	    
	    @FXML 
	    private TextField textNomeLuoghiIST;
	    @FXML 
	    private TextField textCognomeLuoghiIST;
	    @FXML 
	    private TextField textIDStudenteLuoghiIST;
	    @FXML 
	    private TextField textViaLuoghiIST;
	    @FXML 
	    private TextField textNumeroCivicoLuoghiIST;
	    @FXML 
	    private TextField textIDAmbienteStudioLuoghiIST;
	    
	    
	    // Campi Abitudini lavoro
	    @FXML
	    private RadioButton  radioBLuoghiAbitudiniLavorative;
	    
	    @FXML 
	    private TextField textNomeLuoghiLAV;
	    @FXML 
	    private TextField textCognomeLuoghiLAV;
	    @FXML 
	    private TextField textIDLavoratoreLuoghiLAV;
	    @FXML 
	    private TextField textViaLuoghiLAV;
	    @FXML 
	    private TextField textNumeroCivicoLuoghiLAV;
	    @FXML 
	    private TextField textIDAmbienteLavorativoLuoghiLAV;
	    @FXML 
	    private TextField textOrarioIngressoLuoghiLAV;
	    @FXML 
	    private TextField textOrarioUscitaLuoghiLAV;
	    @FXML
	    private DatePicker datePickerLuoghiLAV;
	    
	    // BUTTON PRINCIPALI
	    @FXML 
        private Button buttonAggiungi;

        @FXML
        private Button buttonModifica;

        @FXML
        private Button buttonRicerca;

        @FXML
        private Button buttonSalva;
	    
        //Connessione
        Connection connection = LoginController.getConnection();
	    
	    
        // CAMPI VACCINO
        //dati vaccino
        @FXML
        private RadioButton radioBDatiVaccino;
      
        
        @FXML 
        private TextField textIDVaccinoDatiVaccino;
        
        @FXML
        private TextField textEnteRilascioDatiVaccino;
        
        @FXML
        private TextField textControindicazioniDatiVaccino;
        
        @FXML
        private ChoiceBox<String> tipoVaccinoChoiceBox;
        
        @FXML
        private ChoiceBox<Integer> periodoUtileChoiceBox;
        
    	@FXML private Label labelHelpIDVaccinoDatiVaccino;

		@FXML private TextArea textHelpIDVaccinoDatiVaccino;
        
        //Somministrazione Vaccino
        
        @FXML
        private RadioButton radioBSomministrazioneVaccino;
        
        @FXML
        private TextField textNomeSomministrazioneVaccino;
        
        @FXML
        private TextField textCognomeSomministrazioneVaccino;
        
        @FXML
        private TextField textCodiceFiscaleSomministrazioneVaccino;
        
        @FXML
        private TextField textIDVaccinoSomministrazioneVaccino;

        
        
        
		@FXML private TextField textIDStudenteStudente;

		@FXML private TextField textIDLavoratoreDatiPersonali;

	
        
        
	    
    @FXML 
    public void initialize() {
    		//Inizializza cambio scena generico 
	    	toggleButtonPersona.setOnAction(this::apriPersonaGenerica);
	    	toggleButtonLuogo.setOnAction(this::apriLuogoGenerico);
	    	toggleButtonControlloMedico.setOnAction(this::apriControlloMedico);
	    	toggleButtonIncontri.setOnAction(this::apriGestioneIncontri);
	    	toggleButtonVaccino.setOnAction(this::apriVaccino);
	    	logoutButton.setOnAction(this::logout);
	    	setAllInvisible();
	    	
	    	//Inizializza scena con PERSONA GENERICA Selezionato
	    	radioBDatiPersonali.setOnAction(this::abilitaCampiDatiPersonali);
	    	radioBParentela.setOnAction(this::abilitaCampiParentela);
	    	radioBStatoDellaSalute.setOnAction(this::abilitaCampiStatoSalute);
	    	radioBDatiPersonaliStudente.setOnAction(this::abilitaCampiDatiPersonaliStudente);	
	    	radioBCompagniStudente.setOnAction(this::abilitaCampiDatiCompagni);
	    	radioBDatiPersonaliLavoratore.setOnAction(this::abilitaCampiDatiPersonaliLavoratore);
	    	radioBColleghiLavoratore.setOnAction(this::abilitaCampiDatiColleghi);
	    	
	    	    	
	    	//Inizializza scena con LUOGO GENERICO Selezionato
	        radioBDatiLuogo.setOnAction(this::abilitaCampiLuogo);
	        radioBAmbienteLavoro.setOnAction(this::abilitaCampiAmbienteLavoro);
	        radioBAmbienteStudio.setOnAction(this::abilitaCampiAmbienteStudio);
	        radioBAmbienteFamiliare.setOnAction(this::abilitaCampiAmbienteFamiliare);
	        radioBAmbienteEventoOccasionale.setOnAction(this::abilitaCampiAmbienteEventoOccasionale);
	        radioBGestioneLuogo.setOnAction(this::abilitaCampiGestione);
	        radioBAula.setOnAction(this::abilitaCampiAula);
	    
	        //Inizializza scena con CONTROLLO MEDICO Selezionato
	        radioBDatiControlloMedico.setOnAction(this::abilitaCampiControlloMedico);
	       
	        //Inizializza scena con INCONTRI Selezionato
	        radioBDatiIncontroVisita.setOnAction(this::abilitaCampiVisita);
	        radioBLuoghiIstituzionaliFrequentati.setOnAction(this::abilitaCampiFrequentazioneIstituzionale);
	        radioBLuoghiAbitudiniLavorative.setOnAction(this::abilitaCampiAbitudiniLavorativi);
	        
	        //Inizializza scena con VACCINO
	        radioBDatiVaccino.setOnAction(this::abilitaCampiDatiVaccino);
	        radioBSomministrazioneVaccino.setOnAction(this::abilitaCampiSomministrazioneVaccino);
	        
	        //Enumerazione
	        inizializzaEnumerazioni();
	    	
	        //Vincoli di Ennupla
	   	    inizializzaVincoliEnnupla();
	   	   
	   	    //Vincoli di Dominio
	   	    inizializzaTextFieldNumerico();
	   	    
	   	    
	   	    inizializzaDate();
	   	    inizializzaTooltip();  	    
	   	    
	   	    
	   	  
	   	 buttonAggiungi.setOnAction(this::aggiungi);
         buttonModifica.setOnAction(this::modifica);
         buttonSalva.setOnAction(this::salva);
         buttonSalva.setOnAction(this::ricerca);
	   	    
    }
   
    
    
   // APERTURA FINESTRE  
    
    //Apertura Persona
    void apriPersonaGenerica(ActionEvent event) {
    	if(!toggleButtonPersona.isSelected()) {
    		schermataPersona.setVisible(false);
    	}
    	else {
    		setAllInvisible();
    		schermataPersona.setVisible(true);
    		radioBDatiPersonali.setSelected(true);
    		abilitaCampiDatiPersonali(event);
    		
    	}
    }
    
    //Apertura Luogo
    void apriLuogoGenerico(ActionEvent event) {
    	if(!toggleButtonLuogo.isSelected()) {
    		schermataLuogo.setVisible(false);
    	}
    	else {
    		setAllInvisible();
    		schermataLuogo.setVisible(true);
    		radioBDatiLuogo.setSelected(true);
    		abilitaCampiLuogo(event);	
    		
    	}
    }
    
    //Apertura Controllo medico
    void apriControlloMedico(ActionEvent event) {
    	if(!toggleButtonControlloMedico.isSelected()) {
    		schermataControlloMedico.setVisible(false);
    	}
    	else {
    		setAllInvisible();
    		schermataControlloMedico.setVisible(true);
    		radioBDatiControlloMedico.setSelected(true);
    		abilitaCampiControlloMedico(event);
    	    		
    	}
    }

    //Apertura Incontri
    void apriGestioneIncontri(ActionEvent event) {
    	if(!toggleButtonIncontri.isSelected()) {
    		schermataGestioneIncontri.setVisible(false);
    	}
    	else {
    		setAllInvisible();
    		schermataGestioneIncontri.setVisible(true);
    	    radioBDatiIncontroVisita.setSelected(true);
    	    abilitaCampiVisita(event);
    	}
    }
    
    //Apertura Vaccino
    void apriVaccino(ActionEvent event) {
    	if(!toggleButtonVaccino.isSelected()) {
    		schermataVaccino.setVisible(false);
    	}
    	else {
    		setAllInvisible();
    		 schermataVaccino.setVisible(true);
    		 radioBDatiVaccino.setSelected(true);
    		 abilitaCampiDatiVaccino(event);
    	}
    }
    
    // NASCODE FINESTRE
    public void setAllInvisible() {
    	schermataPersona.setVisible(false);
    	schermataLuogo.setVisible(false);
    	schermataGestioneIncontri.setVisible(false);
    	schermataControlloMedico.setVisible(false);    
    	schermataVaccino.setVisible(false);
    }



 // SCELTA ESCLUSIVA CAMPI PERSONA - STUDENTE - LAVORATORE	

	public void abilitaCampiStatoSalute(ActionEvent actionevent) {
		disableAll();
		ableCampiStatoSalute();
	}


	public void abilitaCampiParentela(ActionEvent actionevent) {
		disableAll();
		ableCampiParentela();
	}


	public void abilitaCampiDatiPersonali(ActionEvent actionevent) {
		disableAll();
		ableCampiDatiPersonali();
	}
    
	public void abilitaCampiDatiPersonaliStudente(ActionEvent event) {
		disableAll();
		ableCampiDatiPersonaliStudente();
		
	}
	
	public void abilitaCampiDatiCompagni(ActionEvent event) {
		disableAll();
		ableCampiCompagni();
		
	}
	
	public void abilitaCampiDatiPersonaliLavoratore(ActionEvent event) {
		disableAll();
		ableCampiDatiPersonaliLavoratore();
		
	}
	public void abilitaCampiDatiColleghi(ActionEvent event) {
		disableAll();
		ableCampiDatiColleghi();
		
	}
	
	
// SCELTA ESCLUSIVA CAMPI LUOGO 
	public void abilitaCampiLuogo(ActionEvent event) {
		disableAll();
		ableCampiDatiLuogo();
		
	}
	
	public void abilitaCampiAmbienteLavoro(ActionEvent event) {
		disableAll();
		ableCampiDatiAmbienteLavoro();
		
	}
	
	public void abilitaCampiAmbienteStudio(ActionEvent event) {
		disableAll();
		ableCampiDatiAmbienteStudio();
		
	}
	
	public void abilitaCampiAula(ActionEvent event) {
		disableAll();
		ableCampiAula();
		
	}
	
	public void abilitaCampiAmbienteFamiliare(ActionEvent event) {
		disableAll();
		ableCampiDatiAmbienteFamiliare();
		
	}
	
	public void abilitaCampiAmbienteEventoOccasionale(ActionEvent event) {
		disableAll();
		ableCampiDatiEventoOccasionale();
		
	}
	
	public void abilitaCampiGestione(ActionEvent event) {
		disableAll();
		ableCampiGestione();
		
	}


//SCELTA CAMPI CONTROLLO MEDICO
	public void abilitaCampiControlloMedico(ActionEvent event) {
		disableAll();
		ableCampiControlloMedico();
	}
	
	//SCELTA CAMPI VISITA
		public void abilitaCampiVisita(ActionEvent event) {
			disableAll();
			ableCampiVisita();
		}
	//SCELTA CAMPI Frequentazione Istituzionale
		public void abilitaCampiFrequentazioneIstituzionale(ActionEvent event) {
			disableAll();
			ableCampiFrequentazioneIstituzionale();
		}
	//Scelta campi Abitudini Lavorativi
		public void abilitaCampiAbitudiniLavorativi(ActionEvent event) {
			disableAll();
			ableCampiAbitudiniLavorativi();
		}
	//Scekta campi Dati Vaccino
		public void abilitaCampiDatiVaccino(ActionEvent event)
		{
			disableAll();
			ableCampiDatiVaccino();
			
		}
	//Scelta campi Somministrazione Vaccino
		public void abilitaCampiSomministrazioneVaccino(ActionEvent event)
		{
			disableAll();
			ableCampiSomministrazioneVaccino();
		}
// DISABILITA CAMPI 
	private void disableAll() {
		//CAMPI PERSONA - STUDENTE - LAVORATORE
			
			//Campi dati personali persona
			textFieldNomePersona.setDisable(true);
			textFieldCognomePersona.setDisable(true);
			textComuneNascitaPersona.setDisable(true);
			textDataNascitaPersona.setDisable(true);
			textFieldCFPersona.setDisable(true);
			textFieldTelefono1Persona.setDisable(true);
			textFieldMail1Persona.setDisable(true);
			textFieldTelefono2Persona.setDisable(true);
			textFieldMail2Persona.setDisable(true);
			tbFemmina.setDisable(true);
			tbMaschio.setDisable(true);
			
			//Campi parentela persona
			sceltaParentela.setDisable(true);
			textFieldPersonaCFParentela1.setDisable(true);
			textFieldPersonaNomeParentela1.setDisable(true);
			textFieldPersonaCognomeParentela1.setDisable(true);
			textFieldPersonaCFParentela2.setDisable(true);
			textFieldPersonaNomeParentela2.setDisable(true);
			textFieldPersonaCognomeParentela2.setDisable(true);
			
			//Campi stato salute persona
			dataSintomiDatePickerStatoSalute.setDisable(true);
			textFieldPersonaCFStatoSalute.setDisable(true);
			textFieldPersonaCognomeStatoSalute.setDisable(true);
			textFieldPersonaNomeStatoSalute.setDisable(true);
			textFieldPersonaMalattieCronicheStatoSalute.setDisable(true);
			sceltaSintomi.setDisable(true);
			tbTamponeEseguitoSi.setDisable(true);
			tbTamponeEseguitoNo.setDisable(true);
			textDataTamponeEseguito.setDisable(true);
			tbQuarantenaSi.setDisable(true);
			tbQuarantenaNo.setDisable(true);
			
			//Campi dati personali studente
			textNomeStudente.setDisable(true);
			textCognomeStudente.setDisable(true);
			textCodiceFiscaleStudente.setDisable(true);
			tbFrequentaInPresenzaNo.setDisable(true);
			tbFrequentaInPresenzaSi.setDisable(true);
			textIDStudenteStudente.setDisable(true);
		
			//Campi compagni studente 
			textNomeCompagno1.setDisable(true);
			textCognomeCompagno1.setDisable(true);
			textCodiceFiscaleCompagno1.setDisable(true);
			textNomeCompagno2.setDisable(true);
			textCognomeCompagno2.setDisable(true);
			textCodiceFiscaleCompagno2.setDisable(true);
		
			//Campi dati personali lavoratore
			textNomeLavoratore.setDisable(true);
	  		textCognomeLavoratore.setDisable(true);
	  		textCodiceFiscaleLavoratore.setDisable(true);
	  		tipoContrattoChoiceBox.setDisable(true);
	  		checkBoxLunediLavoratore.setDisable(true);
	  		checkBoxMartediLavoratore.setDisable(true);
	  		checkBoxMercolediLavoratore.setDisable(true);
	  		checkBoxGiovediLavoratore.setDisable(true);
	  		checkBoxDomenicaLavoratore.setDisable(true);
	  		checkBoxVenerdiLavoratore.setDisable(true);
	  		checkBoxSabatoLavoratore.setDisable(true);
	  		textNomeSocieta.setDisable(true);
	  	
	  		//Campi colleghi lavoratore
	  		textNomeCollega1.setDisable(true);
	     	textCognomeCollega1.setDisable(true);
	     	textCodiceFiscaleCollega1.setDisable(true);
	     	textNomeCollega2.setDisable(true);
	     	textCognomeCollega2.setDisable(true);
	     	textCodiceFiscaleCollega2.setDisable(true);
	     	textIDLavoratoreDatiPersonali.setDisable(true);
	     	
	     // CAMPI LUOGO GENERICO
	     	// Campi luogo
	     	textCityDatiLuogo.setDisable(true);
	     	textProvinciaDatiLuogo.setDisable(true);
	     	textViaDatiLuogo.setDisable(true);
	     	textNumeroCivicoDatiLuogo.setDisable(true);
	     	textCAPDatiLuogo.setDisable(true);
	     	textIDLuogo.setDisable(true);
	     	
	     	//Campi gestione luogo
	    	textCodiceFiscaleGestioneLuogo.setDisable(true);
	    	textCognomeGestioneLuogo.setDisable(true);
	    	textIDLuogoGestioneLuogo.setDisable(true);
	    	textNomeGestioneLuogo.setDisable(true);
	    	textNumCivicoGestioneLuogo.setDisable(true);
	    	textViaGestioneLuogo.setDisable(true);
	     	
	     	//Campi dati ambiente di lavoro 
	     	textOrarioAAmbienteLavoro.setDisable(true);
	    	textOrarioCAmbienteLavoro.setDisable(true);
	    	choicheBoxNumDipendentiAmbieneLavoro.setDisable(true);
	    	textIDLuogoAmbienteLavoro.setDisable(true);
	    	textViaAmbieneLavoro.setDisable(true);
	    	textNumCivicoAmbienteLavoro.setDisable(true);
	    	textIDAmbienteLavoro.setDisable(true);
	    	
	     	//Campi dati ambiente di studio
	    	choicheBoxTipoAmbienteStudio.setDisable(true);
	    	textIDAmbienteStudio.setDisable(true);
	    	textIDLuogoAmbienteStudio.setDisable(true);
	    	textNumCivicoAmbienteStudio.setDisable(true);
	    	textViaAmbienteStudio.setDisable(true);
	    	
	    	//Campi dati ambiente familiare
	    	textDimensioneAmbienteFamiliare.setDisable(true);
	    	textIDAmbienteFamiliare.setDisable(true);
	    	textIDLuogoAmbienteFamiliare.setDisable(true);
	    	textNumCivicoAmbienteFamiliare.setDisable(true);
	    	textViaAmbienteFamiliare.setDisable(true);
	    	choicheBoxTipoAmbienteFamiliare.setDisable(true);
	    	
	    	//Campi dati aula
	    	textID_Aula.setDisable(true);
	    	choicheBoxNumPostiAula.setDisable(true);
	    	textIDAmbienteStudioAula.setDisable(true);
	    	
	    	//Campi dati ambiente evento occasionale
	    	choicheBoxNumPartecipantiAmbienteEventoOccasionale.setDisable(true);
	    	textDimensioniAmbienteEventoOccasionale.setDisable(true);
	    	textIDAmbienteEventoOccasionale.setDisable(true);
	    	textIDLuogoAmbienteEventoOccasionale.setDisable(true);
	    	textNumCivicoAmbienteEventoOccasionale.setDisable(true);
	    	textViaAmbienteEventoOccasionale.setDisable(true);
	    	radioBLuogoApertoSi.setDisable(true);
	    	radioBLuogoApertoNo.setDisable(true);
	    
	    //CAMPI CONTROLLO MEDICO	
	    	//Campi controllo medico
	    	textIDControlloMedico.setDisable(true);
	    	textIDLuogoControlloMedico.setDisable(true);
	    	textNomeControlloMedico.setDisable(true);
	    	textNomeMedicoControlloMedico.setDisable(true);
	    	textNumCivicoControlloMedico.setDisable(true);
	    	textNomeOspedaleControlloMedico.setDisable(true);
	    	textViaControlloMedico.setDisable(true);
	    	textCodiceFiscaleControlloMedico.setDisable(true);
	    	textCognomeControlloMedico.setDisable(true);
	    	choiceBoxEsitoControlloMedico.setDisable(true);
	    	choiceBoxTipoControlloMedico.setDisable(true);
	    	datePickerDataControlloMedico.setDisable(true);
	    //CAMPI INCOTRI
	    	//Campi visita
	    	textCodiceFiscaleDatiIncontro.setDisable(true);
	    	datePickerDataDatiIncontro.setDisable(true);
	    	textNomeDatiIncontro.setDisable(true);
	    	textCognomeDatiIncontro.setDisable(true);
	    	textorarioDatiIncontro.setDisable(true);
	    	textIDLuogoDatiIncontro.setDisable(true);
	    	textNumCivicoDatiIncontro.setDisable(true);
	    	textViaDatiIncontro.setDisable(true);
	    	
	    	//Campi Frequentazione Istituzionale
	    	textNomeLuoghiIST.setDisable(true);
	    	textCognomeLuoghiIST.setDisable(true);
	    	textIDStudenteLuoghiIST.setDisable(true);
	    	textViaLuoghiIST.setDisable(true);
	    	textNumeroCivicoLuoghiIST.setDisable(true);
	    	textIDAmbienteStudioLuoghiIST.setDisable(true);
	    	
	    	//Campi Abitudini Lavorativi
	    	textNomeLuoghiLAV.setDisable(true);
	    	textCognomeLuoghiLAV.setDisable(true);
	    	textIDLavoratoreLuoghiLAV.setDisable(true);
	    	textViaLuoghiLAV.setDisable(true);
	    	textNumeroCivicoLuoghiLAV.setDisable(true);
	    	textIDAmbienteLavorativoLuoghiLAV.setDisable(true);
	    	textOrarioIngressoLuoghiLAV.setDisable(true);
	    	textOrarioUscitaLuoghiLAV.setDisable(true);
	    	datePickerLuoghiLAV.setDisable(true);
    	
	    	//Canpi Dati Vaccino
	    	textIDVaccinoDatiVaccino.setDisable(true);
	    	textEnteRilascioDatiVaccino.setDisable(true);
	    	textControindicazioniDatiVaccino.setDisable(true);
	    	tipoVaccinoChoiceBox.setDisable(true);
	    	periodoUtileChoiceBox.setDisable(true);
	    		
	    	// Campi Somministrazione Vaccino
	    	textNomeSomministrazioneVaccino.setDisable(true);
	    	textCognomeSomministrazioneVaccino.setDisable(true);
	    	textCodiceFiscaleSomministrazioneVaccino.setDisable(true);
	    	textIDVaccinoSomministrazioneVaccino.setDisable(true);
	}
	
// ABILITAZIONE/SCELTA DEL CAMPO
	// CAMPI PERSONA - STUDENTE - LAVORATORE
		
		/********* PERSONA *********/
		
		private void ableCampiDatiPersonali() {
			textFieldNomePersona.setDisable(false);
			textFieldCognomePersona.setDisable(false);
			textComuneNascitaPersona.setDisable(false);
			textDataNascitaPersona.setDisable(false);
			textFieldCFPersona.setDisable(false);
			textFieldTelefono1Persona.setDisable(false);
			textFieldMail1Persona.setDisable(false);
			textFieldTelefono2Persona.setDisable(false);
			textFieldMail2Persona.setDisable(false);
			tbFemmina.setDisable(false);
			tbMaschio.setDisable(false);
		}
		
		
		private void ableCampiParentela() {
			sceltaParentela.setDisable(false);
			textFieldPersonaCFParentela1.setDisable(false);
			textFieldPersonaNomeParentela1.setDisable(false);
			textFieldPersonaCognomeParentela1.setDisable(false);
			textFieldPersonaCFParentela2.setDisable(false);
			textFieldPersonaNomeParentela2.setDisable(false);
			textFieldPersonaCognomeParentela2.setDisable(false);
		}
		
		
		private void ableCampiStatoSalute() {
			if(sceltaSintomi.getValue()!="Asintomatico" && sceltaSintomi.getValue() != null)
				dataSintomiDatePickerStatoSalute.setDisable(false);
			textFieldPersonaCFStatoSalute.setDisable(false);
			textFieldPersonaCognomeStatoSalute.setDisable(false);
			textFieldPersonaNomeStatoSalute.setDisable(false);
			textFieldPersonaMalattieCronicheStatoSalute.setDisable(false);
			sceltaSintomi.setDisable(false);
			tbTamponeEseguitoSi.setDisable(false);
			tbTamponeEseguitoNo.setDisable(false);
			
			if(tbTamponeEseguitoSi.isSelected())
				textDataTamponeEseguito.setDisable(false);
			tbQuarantenaSi.setDisable(false);
			tbQuarantenaNo.setDisable(false);
		}
		
		/********* STUDENTE *********/
		
	    private void ableCampiDatiPersonaliStudente() {
			textNomeStudente.setDisable(false);
			textCognomeStudente.setDisable(false);
			textCodiceFiscaleStudente.setDisable(false);
			tbFrequentaInPresenzaNo.setDisable(false);
			tbFrequentaInPresenzaSi.setDisable(false);
			textIDStudenteStudente.setDisable(false);
			
		}
	    
	    
	    private void ableCampiCompagni() {
			textNomeCompagno1.setDisable(false);
			textCognomeCompagno1.setDisable(false);
			textCodiceFiscaleCompagno1.setDisable(false);
			textNomeCompagno2.setDisable(false);
			textCognomeCompagno2.setDisable(false);
			textCodiceFiscaleCompagno2.setDisable(false);
			
		}
	    
	    /********* LAVORATORE *********/
	    
	    private void ableCampiDatiPersonaliLavoratore() {
	  		textNomeLavoratore.setDisable(false);
	  		textCognomeLavoratore.setDisable(false);
	  		textCodiceFiscaleLavoratore.setDisable(false);
	  		tipoContrattoChoiceBox.setDisable(false);
	  		checkBoxLunediLavoratore.setDisable(false);
	  		checkBoxMartediLavoratore.setDisable(false);
	  		checkBoxMercolediLavoratore.setDisable(false);
	  		checkBoxGiovediLavoratore.setDisable(false);
	  		checkBoxVenerdiLavoratore.setDisable(false);
	  		checkBoxSabatoLavoratore.setDisable(false);
	  		checkBoxDomenicaLavoratore.setDisable(false);
	  		if(tipoContrattoChoiceBox.getValue() != "Libero Professionista" && tipoContrattoChoiceBox.getValue() != null)
	  			textNomeSocieta.setDisable(false);
	  		textIDLavoratoreDatiPersonali.setDisable(false);
	  	}
	    
	    private void ableCampiDatiColleghi() {
	     	 textNomeCollega1.setDisable(false);
	     	 textCognomeCollega1.setDisable(false);
	     	 textCodiceFiscaleCollega1.setDisable(false);
	     	 textNomeCollega2.setDisable(false);
	    	 textCognomeCollega2.setDisable(false);
	    	 textCodiceFiscaleCollega2.setDisable(false);
	    	 
	     }
	    
// CAMPI LUOGO GENERICO - AMBIENTE DI LAVORO - AMBIENTE DI STUDIO - AMBIENTE EVENTO OCCASIONALE - AMBIENTE FAMILIARE 
	    
	    /********* LUOGO *********/
	    private void ableCampiDatiLuogo() {
	      	textCityDatiLuogo.setDisable(false);
	     	textProvinciaDatiLuogo.setDisable(false);
	     	textViaDatiLuogo.setDisable(false);
	     	textNumeroCivicoDatiLuogo.setDisable(false);
	     	textCAPDatiLuogo.setDisable(false);
	     	textIDLuogo.setDisable(false);
	    }
	    
	    private void ableCampiGestione() {
	    	textCodiceFiscaleGestioneLuogo.setDisable(false);
	    	textCognomeGestioneLuogo.setDisable(false);
	    	textIDLuogoGestioneLuogo.setDisable(false);
	    	textNomeGestioneLuogo.setDisable(false);
	    	textNumCivicoGestioneLuogo.setDisable(false);
	    	textViaGestioneLuogo.setDisable(false);
	    }
	    
	    /********* AMBIENTE DI LAVORO *********/
	    private void ableCampiDatiAmbienteLavoro() {
	    	textOrarioAAmbienteLavoro.setDisable(false);
	    	textOrarioCAmbienteLavoro.setDisable(false);
	    	choicheBoxNumDipendentiAmbieneLavoro.setDisable(false);
	    	textIDLuogoAmbienteLavoro.setDisable(false);
	    	textViaAmbieneLavoro.setDisable(false);
	    	textNumCivicoAmbienteLavoro.setDisable(false);
	    	textIDAmbienteLavoro.setDisable(false);
	    }
	    
	    /********* AMBIENTE DI STUDIO *********/
	    private void ableCampiDatiAmbienteStudio() {
	    	choicheBoxTipoAmbienteStudio.setDisable(false);
	    	textIDAmbienteStudio.setDisable(false);
	    	textIDLuogoAmbienteStudio.setDisable(false);
	    	textNumCivicoAmbienteStudio.setDisable(false);
	    	textViaAmbienteStudio.setDisable(false);
	    }
	    
	    //Campi aula 
	    private void ableCampiAula() {
	    	textID_Aula.setDisable(false);
	    	choicheBoxNumPostiAula.setDisable(false);
	    	textIDAmbienteStudioAula.setDisable(false);
	    }
	    
	    /********* AMBIENTE EVENTO OCCASIONALE *********/
	    private void ableCampiDatiEventoOccasionale() {
	    	choicheBoxNumPartecipantiAmbienteEventoOccasionale.setDisable(false);
	    	if(radioBLuogoApertoNo.isSelected())
	    		textDimensioniAmbienteEventoOccasionale.setDisable(false);
	    	textIDAmbienteEventoOccasionale.setDisable(false);
	    	textIDLuogoAmbienteEventoOccasionale.setDisable(false);
	    	textNumCivicoAmbienteEventoOccasionale.setDisable(false);
	    	textViaAmbienteEventoOccasionale.setDisable(false);
	    	radioBLuogoApertoSi.setDisable(false);
	    	radioBLuogoApertoNo.setDisable(false);
	    }
	    
	    /********* AMBIENTE FAMILIARE *********/
	    private void ableCampiDatiAmbienteFamiliare() {
	    	textDimensioneAmbienteFamiliare.setDisable(false);
	    	textIDAmbienteFamiliare.setDisable(false);
	    	textIDLuogoAmbienteFamiliare.setDisable(false);
	    	textNumCivicoAmbienteFamiliare.setDisable(false);
	    	textViaAmbienteFamiliare.setDisable(false);
	    	choicheBoxTipoAmbienteFamiliare.setDisable(false);
	    }

// CAMPI CONTROLLO MEDICO - VISITA 
	    
	    /********* CONTROLLO MEDICO *********/
	    private void ableCampiControlloMedico() {
	    	textIDControlloMedico.setDisable(false);
	    	textIDLuogoControlloMedico.setDisable(false);
	    	textNomeControlloMedico.setDisable(false);
	    	textNomeMedicoControlloMedico.setDisable(false);
	    	textNumCivicoControlloMedico.setDisable(false);
	    	textNomeOspedaleControlloMedico.setDisable(false);
	    	textViaControlloMedico.setDisable(false);
	    	textCodiceFiscaleControlloMedico.setDisable(false);
	    	textCognomeControlloMedico.setDisable(false);
	    	if(choiceBoxTipoControlloMedico.getValue() != "Altro")
	    		choiceBoxEsitoControlloMedico.setDisable(false);
	    	choiceBoxTipoControlloMedico.setDisable(false);
	    	datePickerDataControlloMedico.setDisable(false);
	    	
	    }
	    
	    /********* VISITA *********/
	    private void ableCampiVisita() {
	    	textCodiceFiscaleDatiIncontro.setDisable(false);
	    	datePickerDataDatiIncontro.setDisable(false);
	    	textNomeDatiIncontro.setDisable(false);
	    	textCognomeDatiIncontro.setDisable(false);
	    	textorarioDatiIncontro.setDisable(false);
	    	textIDLuogoDatiIncontro.setDisable(false);
	    	textNumCivicoDatiIncontro.setDisable(false);
	    	textViaDatiIncontro.setDisable(false);
	    }
	    
	    /**** FREQUENTAZIONE ISTITUZIONALE ****/	
	    private void ableCampiFrequentazioneIstituzionale() {
    	 	textNomeLuoghiIST.setDisable(false);
	    	textCognomeLuoghiIST.setDisable(false);
	    	textIDStudenteLuoghiIST.setDisable(false);
	    	textViaLuoghiIST.setDisable(false);
	    	textNumeroCivicoLuoghiIST.setDisable(false);
	    	textIDAmbienteStudioLuoghiIST.setDisable(false);
		    	
	    }
	    
	    /***** ABITUDINI LAVORATIVI  *****/
	    private void ableCampiAbitudiniLavorativi() {
	    	textNomeLuoghiLAV.setDisable(false);
	    	textCognomeLuoghiLAV.setDisable(false);
	    	textIDLavoratoreLuoghiLAV.setDisable(false);
	    	textViaLuoghiLAV.setDisable(false);
	    	textNumeroCivicoLuoghiLAV.setDisable(false);
	    	textIDAmbienteLavorativoLuoghiLAV.setDisable(false);
	    	textOrarioIngressoLuoghiLAV.setDisable(false);
	    	textOrarioUscitaLuoghiLAV.setDisable(false);
	    	datePickerLuoghiLAV.setDisable(false);
	    }
	    
	    /******* DATI VACCINO *****/
	    private void ableCampiDatiVaccino()
	    {
	    	textIDVaccinoDatiVaccino.setDisable(false);
	    	textEnteRilascioDatiVaccino.setDisable(false);
	    	textControindicazioniDatiVaccino.setDisable(false);
	    	tipoVaccinoChoiceBox.setDisable(false);
	    	periodoUtileChoiceBox.setDisable(false);
	    }
	    
	    /***** SOMMINISTRAZIONE VACCINO ****/
	    private void ableCampiSomministrazioneVaccino()
	    {
	    	textNomeSomministrazioneVaccino.setDisable(false);
	    	textCognomeSomministrazioneVaccino.setDisable(false);
	    	textCodiceFiscaleSomministrazioneVaccino.setDisable(false);
	    	textIDVaccinoSomministrazioneVaccino.setDisable(false);
	    }
	    
	    
	    
    
    //VINCOLI PERSONA - STUDENTE - LAVORATORE
    public void checkVincoloTipoContratto(ActionEvent event) {
        if(tipoContrattoChoiceBox.getValue() == "Libero Professionista") {
            textNomeSocieta.setDisable(true);
        }
        else {
            textNomeSocieta.setDisable(false);
        }
    }  
    
    public void checkVincoloTamponeEseguito(ActionEvent event) {
    	tbTamponeEseguitoNo.setOnAction(this::checkVincoloTamponeEseguito);
    	
    	
        if(tbTamponeEseguitoSi.isSelected()) {	
            textDataTamponeEseguito.setDisable(false);
            
        }
        else {
            textDataTamponeEseguito.setDisable(true);
        }
    }
    
    public void checkVincoloSintomatologia(ActionEvent event) {
        if(sceltaSintomi.getValue() == "Asintomatico") {
            dataSintomiDatePickerStatoSalute.setDisable(true);
        }
        else {
            dataSintomiDatePickerStatoSalute.setDisable(false);
        }
    }
    
    //VINCOLI LUOGO 
    public void checkVincoloLuogoAperto(ActionEvent event) {
    	
    	if(radioBLuogoApertoNo.isSelected()) {
    		textDimensioniAmbienteEventoOccasionale.setDisable(false);
    	}
    	else {
    		textDimensioniAmbienteEventoOccasionale.setDisable(true);
    	}
    }
    
    public void checkVincoloTipoControlloMedico(ActionEvent event) {
    	if(choiceBoxTipoControlloMedico.getValue() == "Altro") {
    		choiceBoxEsitoControlloMedico.setDisable(true);
    	}
    	else {
    		choiceBoxEsitoControlloMedico.setDisable(false);
    	}
    }
       
    public void inizializzaEnumerazioni() {
    	ObservableList<Integer> values = FXCollections.observableArrayList();
    	for(int i = 1 ; i<=500 ; i++) {
    		values.add(i);
    	}
    	
    	ObservableList<Integer> values1 = FXCollections.observableArrayList();
    	for(int i = 1 ; i<=200; i++) {
    		values1.add(i);
    	}
    	
    	ObservableList<Integer> values2 = FXCollections.observableArrayList();
    	for(int i = 10 ; i<=180; i = i + 10) {
    		values2.add(i);
    	}
    	
    	
    	//Persona
    	sceltaParentela.setItems(FXCollections.observableArrayList("E' marito di", "E' moglie di", "E' Figlio di", "E' Figlia di", "E' Padre di", "E' Madre di", "E' Zia di", "E' Zio di", "E' Nonno di",	"E' Nonna di", "E' Cugino di", "E' Cugina di", "E' Sorella di", "E' Fratello di"));
    	sceltaSintomi.setItems(FXCollections.observableArrayList("Asintomatico", "Pauci-Sintomatico", "Lieve", "Severe", "Critico", "Guarito"));
    	tipoContrattoChoiceBox.setItems(FXCollections.observableArrayList("Determinato", "Indeterminato", "A Chiamata", "A Progetto", "Libero Professionista"));
    
    	//Luogo
    	choicheBoxNumPartecipantiAmbienteEventoOccasionale.setItems(values1);
    	choicheBoxNumPostiAula.setItems(values1);
    	choicheBoxNumDipendentiAmbieneLavoro.setItems(values);
    	choicheBoxTipoAmbienteStudio.setItems(FXCollections.observableArrayList("Scuola infanzia", "Scuola elementare", "Scuola media", "Scuola superiore", "Universit�"));
    	choicheBoxTipoAmbienteFamiliare.setItems(FXCollections.observableArrayList("Casa", "Appartamento"));
    	
    	//Controllo Medico
    	choiceBoxTipoControlloMedico.setItems(FXCollections.observableArrayList("Tampone", "Test Sierologico", "Altro"));
    	choiceBoxEsitoControlloMedico.setItems(FXCollections.observableArrayList("Positivo", "Negativo", "In attesa"));
    	
    	//Vaccino
    	tipoVaccinoChoiceBox.setItems(FXCollections.observableArrayList("SARS-CoV 2", "Anti-Influenale", "Altro"));
    	periodoUtileChoiceBox.setItems(values2);
    }
   
    public void inizializzaVincoliEnnupla() {
    	//Persona
    	sceltaSintomi.setOnAction(this::checkVincoloSintomatologia);
        tbTamponeEseguitoSi.setOnAction(this::checkVincoloTamponeEseguito);
        tipoContrattoChoiceBox.setOnAction(this::checkVincoloTipoContratto);
    
        //Luogo
        radioBLuogoApertoSi.setOnAction(this::checkVincoloLuogoAperto);
        radioBLuogoApertoNo.setOnAction(this::checkVincoloLuogoAperto);
        
        //Controllo Medico
        choiceBoxTipoControlloMedico.setOnAction(this::checkVincoloTipoControlloMedico);
    }
	
	public void inizializzaDate() {
		limitaData(LocalDate.of(1900, 1, 1),LocalDate.now(), textDataNascitaPersona);
		limitaData(LocalDate.of(2019, 1, 1),LocalDate.now(), dataSintomiDatePickerStatoSalute);
		limitaData(LocalDate.of(2019, 1, 1),LocalDate.now(), textDataTamponeEseguito);
		limitaData(LocalDate.of(2019, 1, 1),LocalDate.now(), datePickerDataControlloMedico);
		limitaData(LocalDate.of(2019, 1, 1),LocalDate.now(), datePickerDataDatiIncontro);	
		limitaData(LocalDate.of(2019, 1, 1), LocalDate.now(), datePickerLuoghiLAV);
	}
    
    public void limitaData(LocalDate minDate, LocalDate maxDate , DatePicker datePicker) {
		
		//LocalDate minDate = LocalDate.of(annoMin, meseMin, giornoMin);
		//LocalDate maxDate = LocalDate.of(annoMax, meseMax, giornoMax);
		
		datePicker.setDayCellFactory(x ->
        new DateCell() {
            @Override 
            public void updateItem(LocalDate item, boolean empty) {
                super.updateItem(item, empty);
                setDisable(item.isAfter(maxDate) || item.isBefore(minDate));
            }
         });
	}
    
    
    public void inizializzaTextFieldNumerico() {
    	//Studente - dati personali
    	formattaTextFieldInNumerico(textIDStudenteStudente);
    	// Lavoratore - dati personali
    	formattaTextFieldInNumerico(textIDLavoratoreDatiPersonali);
    	// Luogo - luogo
    	formattaTextFieldInNumerico(textIDLuogo);
    	// Luogo - gestione luogo
    	formattaTextFieldInNumerico(textIDLuogoGestioneLuogo);
    	
    	// Luogo - dati ambiente di lavoro
    	formattaTextFieldInNumerico(textIDLuogoAmbienteLavoro);
    	formattaTextFieldInNumerico(textIDAmbienteLavoro);
    	
    	// Luogo - dati ambiente di studio
    	formattaTextFieldInNumerico(textIDLuogoAmbienteStudio);
    	formattaTextFieldInNumerico(textIDAmbienteStudio);
    	
    	// Luogo - Aula
    	formattaTextFieldInNumerico(textIDAmbienteStudioAula);
    	formattaTextFieldInNumerico(textID_Aula);

    	// Luogo -  dati ambiente evento occasionale
    	formattaTextFieldInNumerico(textIDLuogoAmbienteEventoOccasionale);
    	formattaTextFieldInNumerico(textIDAmbienteEventoOccasionale);
    	formattaTextFieldInNumerico(textDimensioniAmbienteEventoOccasionale);
    	
    	// Luogo - dati ambiente familaire
    	formattaTextFieldInNumerico(textIDLuogoAmbienteFamiliare);
    	formattaTextFieldInNumerico(textIDAmbienteFamiliare);
    	formattaTextFieldInNumerico(textDimensioneAmbienteFamiliare);
    	
    	// Controllo Medico - Dati visita medica
    	formattaTextFieldInNumerico(textIDControlloMedico);
    	formattaTextFieldInNumerico(textIDLuogoControlloMedico);
    	
    	//Incontri - Dati luoghi visitati
    	formattaTextFieldInNumerico(textIDLuogoDatiIncontro);
    	
    	//Luoghi istituzionali frequentati
    	formattaTextFieldInNumerico(textIDStudenteLuoghiIST);
    	formattaTextFieldInNumerico(textIDAmbienteStudioLuoghiIST);
    	
    	//Abitudini lavorative
    	formattaTextFieldInNumerico(textIDLavoratoreLuoghiLAV);
    	formattaTextFieldInNumerico(textIDAmbienteLavorativoLuoghiLAV);
    	
    	//Dati Vaccino
    	formattaTextFieldInNumerico(textIDVaccinoDatiVaccino);
    	
    	//Somministrazione vaccino
    	formattaTextFieldInNumerico(textIDVaccinoSomministrazioneVaccino);
    	
    	
    }
    
    
    public void formattaTextFieldInNumerico(TextField field) {
    	
    	DecimalFormat format = new DecimalFormat( "#.0" );
    	
    	field.setTextFormatter( new TextFormatter<>(c ->
	    {
	        if ( c.getControlNewText().isEmpty() )
	        {
	            return c;
	        }

	        ParsePosition parsePosition = new ParsePosition( 0 );
	        Object object = format.parse( c.getControlNewText(), parsePosition );

	        if ( object == null || parsePosition.getIndex() < c.getControlNewText().length() )
	        {
	            return null;
	        }
	        else
	        {
	            return c;
	        }
	    }));
    }
    
    public void logout(ActionEvent event) {
    	Stage currentStage = (Stage)radioBDatiPersonali.getScene().getWindow();
    	currentStage.hide();
    	
    	Stage primaryStage = new Stage();
    	AnchorPane	root = new AnchorPane();
		try {
			root = (AnchorPane)FXMLLoader.load(getClass().getResource("LoginController.fxml"));
		} catch (IOException e) {
			Messaggi.MessaggioErroreGenerico();
			e.printStackTrace();
		}
		Scene firstScene = new Scene(root,300,400);
		primaryStage.setScene(firstScene);
		try {
			primaryStage.getIcons().add(new Image(new FileInputStream("C:\\Users\\Carmine\\Eclipse workspaceV2\\Progetto BD 2020-2021\\src\\application\\Immagini\\logocolorato.png")));
		} catch (FileNotFoundException e) {
			Messaggi.MessaggioErroreGenerico();
			e.printStackTrace();
		}
		primaryStage.setTitle("Login");
		primaryStage.show();
		LoginController.logoutDataBase();
    }
    
    public void inizializzaTooltip() {
  	
    	setTooltip(labelHelpCFPersona, textHelpCFPersona);
    	setTooltip(labelHelpIDLuogo, textHelpIDLuogo);
    	setTooltip(labelHelpIDAmbienteLavoro, textHelpIDAmbienteLavoro);
    	setTooltip(labelHelpIDAmbienteStudio, textHelpIDAmbienteStudio);
    	setTooltip(labelHelpIDAula, textHelpIDAula);
    	setTooltip(labelHelpIDAmbienteEventoOcc, textHelpIDAmbienteEventoOcc);
    	setTooltip(labelHelpIDAmbienteFamiliare, textHelpIDAmbienteFamiliare);
    	setTooltip(labelHelpIDControlloMedico, textHelpIDControlloMedico);
    	setTooltip(labelHelpIDStudente, textHelpIDStudente);
    	setTooltip(labelHelpIDLavoratore, textHelpIDLavoratore);
    	setTooltip(labelHelpIDVaccinoDatiVaccino, textHelpIDVaccinoDatiVaccino);
    	
    	
    	
    }
    
    
    public void setTooltip(Label label, TextArea textArea) {
    	label.setOnMouseEntered(new EventHandler<Event>() {

   			@Override
   			public void handle(Event event) {
   				textArea.setVisible(true);
   				
   			}
    	    	
    	});
    	
    	label.setOnMouseExited(new EventHandler<Event>() {

   			@Override
   			public void handle(Event event) {
   				textArea.setVisible(false);
   				
   			}
    	    	
    	});
    }
    
    
    public void modifica(ActionEvent e) {
		  
		  try {
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery("SELECT * FROM Persona  WHERE DATANASCITA = '04-MAR-96' " );
			while (rs.next()) {
	
				String nome = rs.getString("nome");
				  String cognome = rs.getString("cognome");
				  String codicefiscale = rs.getString("codicefiscale");
				  String et� = rs.getString("DATANASCITA");
				  String stringf = String.format("%-15s %-15s %-20s %-20s %s\n", nome, cognome,codicefiscale,et�,nome);
				  console2.setText(console2.getText()+stringf);
			}
		  } 
		  catch (SQLException e1) {
			Messaggi.MessaggioErroreGenerico();
			e1.printStackTrace();
		  }
  }

    public void modificaB(ActionEvent e) {
		  manipolaDatabase(3);
	
		  try {
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery("SELECT * FROM Persona  WHERE datanascita = '4-MAR-1996' " );
			while (rs.next()) {
	
				  String nome = rs.getString("nome");
				  String cognome = rs.getString("cognome");
				  String codicefiscale = rs.getString("codicefiscale");
				  String et� = rs.getString("DATANASCITA");
				  String stringf = String.format("%-15s %-15s %-20s %-20s %s\n", nome, cognome,codicefiscale,et�,nome);
				  console2.setText(console2.getText()+stringf);
			}
		  } 
		  catch (SQLException e1) {
			Messaggi.MessaggioErroreGenerico();
			e1.printStackTrace();
		  }
  }
    
  public void ricerca(ActionEvent e) {
	 manipolaDatabase(2);
  }
  public void salva(ActionEvent e) {
 	 manipolaDatabase(1);
  }
  
  public void aggiungi(ActionEvent e) {
	  manipolaDatabase(0);
  }
  public void manipolaDatabase(int mod) {
	  Toggle toggleSelected = toggleGroupSelezioneCampiPersonaGenerica.getSelectedToggle();

	  if(toggleSelected.equals(radioBDatiPersonali)) {
		  String nome = textFieldNomePersona.getText();
		  String cognome = textFieldCognomePersona.getText();
		  String comuneNascita = textComuneNascitaPersona.getText();
		  String codiceFiscale = textFieldCFPersona.getText();
		  String numeroTelefono1 = textFieldTelefono1Persona.getText();
		  String mail1 = textFieldMail1Persona.getText();
		  String numeroTelefono2 = textFieldTelefono2Persona.getText();
		  String mail2 = textFieldMail2Persona.getText();
		  String dataNascita = formattaDataPerQuery(textDataNascitaPersona); 
		  String sesso = null;
		 // String residenza = textFieldResidenza.getText();
		  String residenza = "Residenza";
		  if(tbMaschio.isSelected()) 
			  sesso = "M";
		  else if(tbFemmina.isSelected())
			  sesso = "F";
		  
		  if(mod == 0) {
			//  queryAggiungiPersona(nome,cognome,comuneNascita,codiceFiscale,numeroTelefono1,mail1,numeroTelefono2,mail2,dataNascita,sesso,residenza);	
			  queryAggiungiPersona();
		  }
			 
		  else if(mod == 1)
			  queryModificaPersona(nome,cognome,comuneNascita,codiceFiscale,numeroTelefono1,mail1,numeroTelefono2,mail2,dataNascita,sesso,residenza);
		  else if(mod == 2)
			  queryRicercaPersona(nome,cognome,comuneNascita,codiceFiscale,numeroTelefono1,mail1,numeroTelefono2,mail2,dataNascita,sesso,residenza);
		  else if(mod == 3)
			  recuperaPersonaDB(codiceFiscale);
		  else 
			  Messaggi.MessaggioErroreGenerico();
	  }
	  else if(toggleSelected.equals(radioBDatiPersonaliStudente)) {
		  String nome = textNomeStudente.getText();
		  String cognome = textCognomeStudente.getText();
		  String codiceFiscale = textCodiceFiscaleStudente.getText();
		  Integer frequentaInPresenza = null;
		  if(tbFrequentaInPresenzaSi.isSelected())
			  frequentaInPresenza = 1 ;
		  else if (tbFrequentaInPresenzaNo.isSelected())
			  frequentaInPresenza = 0;
		  String idStudente = textIDStudenteStudente.getText();


		  queryAggiungiStudente(nome,cognome,codiceFiscale,frequentaInPresenza,idStudente);
	  }

	  else if(toggleSelected.equals(radioBDatiPersonaliLavoratore)) {
		  String nome = textNomeLavoratore.getText();
		  String cognome = textCognomeLavoratore.getText();
		  String codiceFiscale = textCodiceFiscaleLavoratore.getText();
		//  String giorniLavorativi = formattaGiorniLavorativi(); 
		  String tipoContratto = tipoContrattoChoiceBox.getValue();
		  String nomeSociet� = textNomeSocieta.getText();
		  String idLavoratore = textIDLavoratoreDatiPersonali.getText();

		  // queryAggiungiLavoratore(nome,cognome,codiceFiscale,giorniLavorativi,tipoContratto,nomeSociet�,idLavoratore);
	  }

	  else if(toggleSelected.equals(radioBParentela)) {
		  String nome1 = textFieldPersonaNomeParentela1.getText();
		  String cognome1 = textFieldPersonaCognomeParentela1.getText();
		  String codiceFiscale1 = textFieldPersonaCFParentela1.getText();
		  String tipoParentela = sceltaParentela.getValue();
		  String nome2 = textFieldPersonaNomeParentela2.getText();
		  String cognome2 = textFieldPersonaCognomeParentela2.getText();
		  String codiceFiscale2 = textFieldPersonaCFParentela2.getText();

		  queryAggiungiParentela(nome1, cognome1, codiceFiscale1, tipoParentela, nome2, cognome2, codiceFiscale2);
	  }

	  else if(toggleSelected.equals(radioBStatoDellaSalute)) {
		  String nome = textFieldPersonaNomeStatoSalute.getText();
		  String cognome = textFieldPersonaCognomeStatoSalute.getText();
		  String codiceFiscale = textFieldPersonaCFStatoSalute.getText();
		  String sintomatologia = sceltaSintomi.getValue();
		  String dataInizioSintomi = formattaDataPerQuery(dataSintomiDatePickerStatoSalute);
		  Integer quarantena = null;
		  if(tbQuarantenaSi.isSelected())
			  quarantena = 1;
		  else 
			  quarantena = 0;
		  Integer tamponeEseguito = null;
		  if(tbTamponeEseguitoSi.isSelected())
			  tamponeEseguito = 1;
		  else 
			  tamponeEseguito = 0;
		  String dataTamponeEseguito = formattaDataPerQuery(textDataTamponeEseguito);
		  String malattieCroniche = textFieldPersonaMalattieCronicheStatoSalute.getText();

		  queryAggiungiStatoSalute(nome, cognome, codiceFiscale, sintomatologia, dataInizioSintomi, quarantena, tamponeEseguito, dataTamponeEseguito, malattieCroniche);
	  }

	  else if(toggleSelected.equals(radioBCompagniStudente)) {
		  String nome1 = textNomeCompagno1.getText();
		  String cognome1 = textCognomeCompagno1.getText();
		  String codiceFiscale1 = textCodiceFiscaleCompagno1.getText();
		  String nome2 = textNomeCompagno2.getText();
		  String cognome2 = textCognomeCompagno2.getText();
		  String codiceFiscale2 = textCodiceFiscaleCompagno2.getText();

		  queryAggiungiCompagni(nome1, cognome1, codiceFiscale1, nome2, cognome2, codiceFiscale2);
	  }

	  else if(toggleSelected.equals(radioBColleghiLavoratore)) {
		  String nome1 = textNomeCollega1.getText();
		  String cognome1 = textCognomeCollega1.getText();
		  String codiceFiscale1 = textCodiceFiscaleCollega1.getText();
		  String nome2 = textNomeCollega2.getText();
		  String cognome2 = textCognomeCollega2.getText();
		  String codiceFiscale2 = textCodiceFiscaleCollega2.getText();

		  queryAggiungiColleghi(nome1, cognome1, codiceFiscale1, nome2, cognome2, codiceFiscale2);
	  }

	  else if(toggleSelected.equals(radioBDatiLuogo)) {
		  String citta = textCityDatiLuogo.getText();
		  String provincia = textProvinciaDatiLuogo.getText();
		  String via = textViaDatiLuogo.getText();
		  String numeroCivico = textNumeroCivicoDatiLuogo.getText();
		  String cap = textCAPDatiLuogo.getText();
		  String idLuogo = textIDLuogo.getText();

		  queryAggiungiLuogo(citta, provincia,via,numeroCivico,cap,idLuogo);
	  }

	  else if(toggleSelected.equals(radioBGestioneLuogo)) {
		  String nomeGestore = textNomeGestioneLuogo.getText();
		  String cognomeGestore = textCognomeGestioneLuogo.getText();
		  String codiceFiscaleGestore = textCodiceFiscaleGestioneLuogo.getText();
		  String viaGestita = textViaGestioneLuogo.getText();
		  String numCivicoGestito = textNumCivicoGestioneLuogo.getText();
		  String idLuogoGestito = textIDLuogoGestioneLuogo.getText();

		  queryAggiungiGestioLuogo(nomeGestore,cognomeGestore,codiceFiscaleGestore,viaGestita,numCivicoGestito,idLuogoGestito);

	  }

	  else if(toggleSelected.equals(radioBAmbienteLavoro)) {
		  String via = textViaAmbieneLavoro.getText();
		  String numeroCivico = textNumCivicoAmbienteLavoro.getText();
		  String idLuogo = textIDLuogoAmbienteLavoro.getText();
		  String orarioA = textOrarioAAmbienteLavoro.getText();
		  String orarioC = textOrarioCAmbienteLavoro.getText();
		  Integer dipendentiMax = choicheBoxNumDipendentiAmbieneLavoro.getValue();
		  String idAmbienteLavoro = textIDAmbienteLavoro.getText();

		  queryAggiungiAmbienteLavoro(via,numeroCivico,idLuogo,orarioA,orarioC,dipendentiMax,idAmbienteLavoro);

	  }

	  else if(toggleSelected.equals(radioBAmbienteStudio)) {
		  String via = textViaAmbienteStudio.getText();
		  String numeroCivico = textNumCivicoAmbienteStudio.getText();
		  String idLuogo = textIDLuogoAmbienteStudio.getText();
		  String tipoAmbiente = choicheBoxTipoAmbienteStudio.getValue();
		  String idAmbienteStudio = textIDAmbienteStudio.getText();

		  queryAggiungiAmbienteStudio(via,numeroCivico,idLuogo,tipoAmbiente,idAmbienteStudio);

	  }

	  else if(toggleSelected.equals(radioBAula)) {
		  String idAmbienteStudio = textIDAmbienteStudioAula.getText();
		  Integer numeroPostiMax = choicheBoxNumPostiAula.getValue();
		  String idAula = textID_Aula.getText();

		  queryAggiungiAula(idAmbienteStudio,numeroPostiMax,idAula);

	  }

	  else if(toggleSelected.equals(radioBAmbienteEventoOccasionale)) {
		  String via = textViaAmbienteEventoOccasionale.getText();
		  String numeroCivico = textNumCivicoAmbienteEventoOccasionale.getText();
		  String idLuogo = textIDLuogoAmbienteEventoOccasionale.getText();
		  Integer luogoAperto = null;
		  if(radioBLuogoApertoSi.isSelected())luogoAperto=1;
		  else if(radioBLuogoApertoNo.isSelected())luogoAperto=0;
		  String dimensione = textDimensioniAmbienteEventoOccasionale.getText();
		  Integer numPartecipanti = choicheBoxNumPartecipantiAmbienteEventoOccasionale.getValue();
		  String idAmbienteEventoOccasionale = textIDAmbienteEventoOccasionale.getText();

		  queryAggiungiAmbienteEventoOccasionale(via,numeroCivico,idLuogo,luogoAperto,dimensione,numPartecipanti,idAmbienteEventoOccasionale);


	  }

	  else if(toggleSelected.equals(radioBAmbienteFamiliare)) {
		  String via = textViaAmbienteFamiliare.getText();
		  String numeroCivico = textNumCivicoAmbienteFamiliare.getText();
		  String idLuogo = textIDLuogoAmbienteFamiliare.getText();
		  String tipo = choicheBoxTipoAmbienteFamiliare.getValue();
		  String dimensione = textDimensioneAmbienteFamiliare.getText();
		  String idAmbienteFamiliare = textIDAmbienteFamiliare.getText();

		  queryAggiungiAmbienteFamiliare(via, numeroCivico, idLuogo, tipo, dimensione, idAmbienteFamiliare);
	  }

	  else if(toggleSelected.equals(radioBDatiControlloMedico)) {
		  String nomeMedico = textNomeMedicoControlloMedico.getText();
		  String nomeStruttura = textNomeOspedaleControlloMedico.getText();
		  String tipo = choiceBoxTipoControlloMedico.getValue();
		  String esito = choiceBoxEsitoControlloMedico.getValue();
		  String data = formattaDataPerQuery(datePickerDataControlloMedico);
		  String IDControlloMedico = textIDControlloMedico.getText();
		  String nome = textNomeControlloMedico.getText();
		  String cognome = textCognomeControlloMedico.getText();
		  String codicefiscale = textCodiceFiscaleControlloMedico.getText();
		  String via = textViaControlloMedico.getText();
		  String numero_civico = textNumCivicoControlloMedico.getText();
		  String id_luogo = textIDLuogoControlloMedico.getText();


		  queryAggiungiDatiVisitaMedica(nomeMedico, nomeStruttura, tipo, esito, data, IDControlloMedico, nome, cognome, codicefiscale, via, numero_civico, id_luogo);
	  }

	  else if(toggleSelected.equals(radioBDatiIncontroVisita)) {
		  String nome = textNomeDatiIncontro.getText();
		  String cognome = textCognomeDatiIncontro.getText();
		  String codicefiscale = textCodiceFiscaleDatiIncontro.getText();
		  String via = textViaDatiIncontro.getText();
		  String numero_civico = textNumCivicoDatiIncontro.getText();
		  String id_luogo = textIDLuogoDatiIncontro.getText();
		  String data = formattaDataPerQuery(datePickerDataDatiIncontro);
		  String orario = textorarioDatiIncontro.getText();

		  queryAggiungiDatiVisita(nome, cognome, codicefiscale, via, numero_civico, id_luogo, data, orario);
	  }

	  else if(toggleSelected.equals(radioBLuoghiIstituzionaliFrequentati)) {
		  String nome = textNomeLuoghiIST.getText();
		  String cognome = textCognomeLuoghiIST.getText();
		  String id_studente = textIDStudenteLuoghiIST.getText();
		  String via = textViaLuoghiIST.getText();
		  String numero_civico = textNumeroCivicoLuoghiIST.getText();
		  String id_ambiente_studio = textIDAmbienteStudioLuoghiIST.getText();

		  queryAggiungiFrequentazioneIstituzionale(nome, cognome, id_studente, via, numero_civico, id_ambiente_studio);
	  }

	  else if(toggleSelected.equals(radioBLuoghiAbitudiniLavorative)) {
		  String nome = textNomeLuoghiLAV.getText();
		  String cognome = textCognomeLuoghiLAV.getText();
		  String id_lavoratore = textIDLavoratoreLuoghiLAV.getText();
		  String via = textViaLuoghiLAV.getText();
		  String numero_civico = textNumeroCivicoLuoghiLAV.getText();
		  String data = formattaDataPerQuery(datePickerLuoghiLAV);
		  String orarioIngresso = textOrarioIngressoLuoghiLAV.getText();
		  String orarioUscita = textOrarioUscitaLuoghiLAV.getText();

		  queryAggiungiAbitudiniLavorative(nome, cognome, id_lavoratore, via, numero_civico, data, orarioIngresso, orarioUscita);
	  }
	  else if(toggleSelected.equals(radioBDatiVaccino)) {
		  String idVaccino = textIDVaccinoDatiVaccino.getText();
		  String enteRilascio = textEnteRilascioDatiVaccino.getText();
		  String controindicazioni = textControindicazioniDatiVaccino.getText();
		  String tipoVaccino = tipoVaccinoChoiceBox.getValue();
		  Integer periodoUtile = periodoUtileChoiceBox.getValue();

		  queryAggiungiVaccino(idVaccino,enteRilascio,controindicazioni,tipoVaccino,periodoUtile);
	  }

	  else if(toggleSelected.equals(radioBSomministrazioneVaccino)) {
		  String nome = textNomeSomministrazioneVaccino.getText();
		  String cognome = textCognomeSomministrazioneVaccino.getText();
		  String codiceFiscale = textCodiceFiscaleSomministrazioneVaccino.getText();
		  String idVaccino = textIDVaccinoSomministrazioneVaccino.getText();

		  queryAggiungiSomministrazione(nome,cognome,codiceFiscale,idVaccino);
	  }
  }
  
  private void recuperaPersonaDB(String codiceFiscale) {
	// TODO Auto-generated method stub
	
}



private void queryRicercaPersona(String nome, String cognome, String comuneNascita, String codiceFiscale,
		String numeroTelefono1, String mail1, String numeroTelefono2, String mail2, String dataNascita, String sesso,
		String residenza) {
	// TODO Auto-generated method stub
	
}



private void queryModificaPersona(String nome, String cognome, String comuneNascita, String codiceFiscale,
		String numeroTelefono1, String mail1, String numeroTelefono2, String mail2, String dataNascita, String sesso,
		String residenza) {
	// TODO Auto-generated method stub
	
}



public void queryAggiungiPersona(String nome, String cognome, String comuneNascita, String codiceFiscale, String numeroTelefono1, String mail1, String numeroTelefono2, String mail2, String dataNascita, String sesso, String residenza) {

//	  //Query aggiunta persona
//	  try {
//		  Statement 	statement = connection.createStatement();
//
//		  console2.appendText("La query : INSERT INTO persona ( nome,  cognome,  comuneNascita, residenza, sesso, codiceFiscale,  Telefono1,  mail1,  Telefono2,  mail2,  dataNascita) VALUES ("
//				  +formattaStringaConApici(nome)+","
//				  +formattaStringaConApici(cognome)+","
//				  +formattaStringaConApici(comuneNascita)+","
//				  +formattaStringaConApici(residenza)+","
//				  +formattaStringaConApici(sesso)+","
//				  +formattaStringaConApici(codiceFiscale)+","
//				  +formattaStringaConApici(numeroTelefono1)+","
//				  +formattaStringaConApici(mail1)+","
//				  +formattaStringaConApici(numeroTelefono2)+","
//				  +formattaStringaConApici(mail2)+","
//				  +formattaStringaConApici(dataNascita)+")\n"
//				  );
//
//		  ResultSet rs = statement.executeQuery("INSERT INTO persona ( nome,  cognome,  comuneNascita, residenza, sesso,  codiceFiscale, Telefono1,  mail1,  Telefono2,  mail2,  dataNascita) VALUES ("
//				  +formattaStringaConApici(nome)+","
//				  +formattaStringaConApici(cognome)+","
//				  +formattaStringaConApici(comuneNascita)+","
//				  +formattaStringaConApici(residenza)+","
//				  +formattaStringaConApici(sesso)+","
//				  +formattaStringaConApici(codiceFiscale)+","
//				  +formattaStringaConApici(numeroTelefono1)+","
//				  +formattaStringaConApici(mail1)+","
//				  +formattaStringaConApici(numeroTelefono2)+","
//				  +formattaStringaConApici(mail2)+","
//				  +formattaStringaConApici(dataNascita)+")"
//				  );
//
//
//	  } catch (SQLException e1) {
//
//		  console2.appendText(e1.getMessage()+"\n");
//		  return;
//	  }
//	  console2.appendText("Persona aggiunta con successo\n");

  }

  private void queryAggiungiParentela(String nome1, String cognome1, String codiceFiscale1, String tipoParentela,
		  String nome2, String cognome2, String codiceFiscale2) {
	  // TODO Auto-generated method stub

  }


  private void queryAggiungiStatoSalute(String nome, String cognome, String codiceFiscale, String sintomatologia,
		  String dataInizioSintomi, Integer quarantena, Integer tamponeEseguito, String dataTamponeEseguito,
		  String malattieCroniche) {
	  // TODO Auto-generated method stub

  }


  public void queryAggiungiStudente(String nome, String cognome, String codiceFiscale, Integer frequentaInPresenza,String idStudente) {


  }


  private void queryAggiungiCompagni(String nome1, String cognome1, String codiceFiscale1, String nome2, String cognome2,
		  String codiceFiscale2) {
	  // TODO Auto-generated method stub

  }


  public void queryAggiungiLavoratore(String nome, String cognome, String codiceFiscale, String giorniLavorativi,
		  String tipoContratto, String nomeSociet�, String idLavoratore) {


  }


  private void queryAggiungiColleghi(String nome1, String cognome1, String codiceFiscale1, String nome2, String cognome2,
		  String codiceFiscale2) {
	  // TODO Auto-generated method stub

  }


  private void queryAggiungiLuogo(String citta, String provincia, String via, String numeroCivico, String cap,
		  String idLuogo) {
	  // TODO Auto-generated method stub

  }


  private void queryAggiungiGestioLuogo(String nomeGestore, String cognomeGestore, String codiceFiscaleGestore,
		  String viaGestita, String numCivicoGestito, String idLuogoGestito) {
	  // TODO Auto-generated method stub

  }


  private void queryAggiungiAmbienteLavoro(String via, String numeroCivico, String idLuogo, String orarioA,
		  String orarioC, Integer dipendentiMax, String idAmbienteLavoro) {
	  // TODO Auto-generated method stub

  }


  private void queryAggiungiAmbienteStudio(String via, String numeroCivico, String idLuogo, String tipoAmbiente,
		  String idAmbienteStudio) {
	  // TODO Auto-generated method stub

  }


  private void queryAggiungiAula(String idAmbienteStudio, Integer numeroPostiMax, String idAula) {
	  // TODO Auto-generated method stub

  }


  private void queryAggiungiAmbienteEventoOccasionale(String via, String numeroCivico, String idLuogo,
		  Integer luogoAperto, String dimensione, Integer numPartecipanti, String idAmbienteEventoOccasionale) {
	  // TODO Auto-generated method stub

  }


  private void queryAggiungiAmbienteFamiliare(String via, String numeroCivico, String idLuogo, String tipo,
		  String dimensione, String idAmbienteFamiliare) {
	  // TODO Auto-generated method stub

  }


  private void queryAggiungiDatiVisitaMedica(String nomeMedico, String nomeStruttura, String tipo, String esito,
		  String data, String iDControlloMedico, String nome, String cognome, String codicefiscale, String via,
		  String numero_civico, String id_luogo) {
	  // TODO Auto-generated method stub

  }


  private void queryAggiungiDatiVisita(String nome, String cognome, String codicefiscale, String via,
		  String numero_civico, String id_luogo, String data, String orario) {
	  // TODO Auto-generated method stub

  }
 
  
  private void queryAggiungiFrequentazioneIstituzionale(String nome, String cognome, String id_studente, String via,
		  String numero_civico, String id_ambiente_studio) {
	  // TODO Auto-generated method stub

  }

  
  private void queryAggiungiAbitudiniLavorative(String nome, String cognome, String id_lavoratore, String via,
		  String numero_civico, String data, String orarioIngresso, String orarioUscita) {
	  // TODO Auto-generated method stub

  }


  private void queryAggiungiVaccino(String idVaccino, String enteRilascio, String controindicazioni, String tipoVaccino,
		  Integer periodoUtile) {
	  // TODO Auto-generated method stub

  }


  private void queryAggiungiSomministrazione(String nome, String cognome, String codiceFiscale, String idVaccino) {
	  // TODO Auto-generated method stub

  }
  
  public void queryAggiungiPersona() {
	  System.out.println("Debug1");
	  
  	String nome = textFieldNomePersona.getText();
		String cognome = textFieldCognomePersona.getText();
		String comuneNascita = textComuneNascitaPersona.getText();
		String codiceFiscale = textFieldCFPersona.getText();
		String numeroTelefono1 = textFieldTelefono1Persona.getText();
		System.out.println("Debug2");
		int numeroGiorno = textDataNascitaPersona.getValue().getDayOfMonth();  
		int numeroAnno = textDataNascitaPersona.getValue().getYear();
		String nomeMeseNascita = textDataNascitaPersona.getValue().getMonth().name(); //Mese in inglese 
		String sesso ;
		String mail1 = textFieldMail1Persona.getText();
		String numeroTelefono2 = textFieldTelefono2Persona.getText();
		String mail2 = textFieldMail2Persona.getText();
		String queryString = funzioneRicercaPersona(nome, null, null);
		System.out.println("Debug3");
			if(tbMaschio.isSelected()) sesso = "M";
			else sesso = "F";
			
		try {
			Statement 	statement = connection.createStatement();
			String sql = "select * from Persona where nome =? and cognome=?";

			PreparedStatement preparedStatement =
			        connection.prepareStatement(sql);

			preparedStatement.setString(1, "Carmine");
		

			ResultSet rs = preparedStatement.executeQuery();
			
		//	ResultSet rs = statement.executeQuery(queryString);
		//	ResultSet rs = statement.executeQuery("SELECT nome, cognome FROM PERSONA WHERE nome = '" + nome + "'" );
			while (rs.next()) {
				 nome = rs.getString("nome");
				 codiceFiscale = rs.getString("codicefiscale");
				  String stringf = String.format("%-15s %-15s \n", nome, codiceFiscale);
				
				  console2.setText(console2.getText()+stringf);
			}

		} catch (SQLException e1) {
			
			e1.printStackTrace();
		}
		
  }
  
  public static String funzioneRicercaPersona(String nome, String cognome, String comune){
		String select = "SELECT ";
		String target = "FROM Persona ";
		String where = "WHERE ";
		String Query = "";
		
			if(nome != null){
				select = select.concat("nome, ");
				where = where.concat("nome = '" + nome + "', " );
				//System.out.println("Debug1"+select + target + where);
			}
			if(cognome != null) {
				 select = select.concat("cognome, ");
				where = where.concat("cognome = '" + cognome + "', ");
			//	System.out.println("Debug2"+ select + target + where);
			}
			if(comune != null) {
				select = select.concat("comune, ");
				where = where.concat("comuneNascita = '" + comune + "', ");
			//	System.out.println("Debug3" + select + target + where);
			}
			
			 select = select.substring(0, select.length() - 2);
			 select = select.concat(" ");
			 
			 where = where.substring(0, where.length() - 2);
			// where = where.concat(";");
			
			Query =	Query.concat(select.concat(target.concat(where)));
			System.out.println(Query);
			return Query;
		}
  
  
  
  public String formattaDataPerQuery(DatePicker dataDaFormattare) {
      String dataFormattata = null; 
      if(textDataNascitaPersona.getValue()!=null) {
            int numeroGiorno = dataDaFormattare.getValue().getDayOfMonth();
            int numeroAnno = dataDaFormattare.getValue().getYear();
            String nomeMeseNascita = dataDaFormattare.getValue().getMonth().name().substring(0, 3); //Mese in inglese 
            dataFormattata =numeroGiorno+"-"+nomeMeseNascita+"-"+numeroAnno;
        }
      return dataFormattata;
  }
  
    
}




